<section class="inside_header">
	<img src="<?=base_url('/uploads/page/'.$pageContent->image)?>" alt="<?=$pageContent->page_name?>">
</section>
<div class="container py-4">
    <h1><?=$staticContent->title?></h1>
    <div class="comn_text">
    <?=$staticContent->description?>
    </div>  
    <div class="clear"></div>
</div>
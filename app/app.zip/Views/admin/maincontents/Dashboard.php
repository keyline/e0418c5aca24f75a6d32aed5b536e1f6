<div class="pcoded-content">
    <h1>Welcome To Master Admin</h1>
    <!-- <div class="row">
        <div class="col-md-4 col-xl-4">
            <a href="<?php echo base_url('admin/'); ?>/manage_package">
                <div class="card bg-c-blue order-card">
                    <div class="card-body">
                        <h6 class="text-white">Packages</h6>
                        <h2 class="text-right text-white"><i class="fas fa-clipboard-list float-left"></i><span>
                            <?=$package_count?>
                        </span></h2>                        
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-4 col-xl-4">
            <a href="<?php echo base_url('admin/'); ?>/manage_event_zones">
                <div class="card bg-c-yellow order-card">
                    <div class="card-body">
                        <h6 class="text-white">Event Zones</h6>
                        <h2 class="text-right text-white"><i class="fas fa-list-alt float-left"></i><span>
                            <?=$event_zone_count?>
                        </span></h2>                        
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-4 col-xl-4">
            <a href="<?php echo base_url('admin/'); ?>/manage_member_type">
                <div class="card bg-c-green order-card">
                    <div class="card-body">
                        <h6 class="text-white">Member Types</h6>
                        <h2 class="text-right text-white"><i class="fas fa-users float-left"></i><span>
                            <?=$member_type_count?>
                        </span></h2>                        
                    </div>
                </div>
            </a>
        </div>

        <div class="col-md-4 col-xl-4">
            <a href="<?php echo base_url('admin/'); ?>/manage_event_category">
                <div class="card bg-c-blue order-card">
                    <div class="card-body">
                        <h6 class="text-white">Event Categories</h6>
                        <h2 class="text-right text-white"><i class="fas fa-clipboard-list float-left"></i><span>
                            <?=$event_cat_count?>
                        </span></h2>                        
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-4 col-xl-4">
            <a href="<?php echo base_url('admin/'); ?>/manage_event">
                <div class="card bg-c-yellow order-card">
                    <div class="card-body">
                        <h6 class="text-white">Events</h6>
                        <h2 class="text-right text-white"><i class="fas fa-list-alt float-left"></i><span>
                            <?=$event_count?>
                        </span></h2>                        
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-4 col-xl-4">
            <a href="<?php echo base_url('admin/'); ?>/manage_user">
                <div class="card bg-c-green order-card">
                    <div class="card-body">
                        <h6 class="text-white">Registered Users</h6>
                        <h2 class="text-right text-white"><i class="fas fa-users float-left"></i><span>
                            <?=$user_count?>
                        </span></h2>                        
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-4 col-xl-4">
            <a href="<?php echo base_url('admin/'); ?>/manage_booking">
                <div class="card bg-c-blue order-card">
                    <div class="card-body">
                        <h6 class="text-white">Bookings</h6>
                        <h2 class="text-right text-white"><i class="fas fa-rupee-sign float-left"></i><span>
                            <?=$booking_count?>
                        </span></h2>                        
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-4 col-xl-4">
            <a href="<?php echo base_url('admin/'); ?>/manage_booking">
                <div class="card bg-c-green order-card">
                    <div class="card-body">
                        <h6 class="text-white">PAID Bookings</h6>
                        <h2 class="text-right text-white"><i class="fas fa-rupee-sign float-left"></i><span>
                            <?=$paid_booking_count?>
                        </span></h2>                        
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-4 col-xl-4">
            <a href="<?php echo base_url('admin/'); ?>/manage_booking">
                <div class="card bg-c-red order-card">
                    <div class="card-body">
                        <h6 class="text-white">UNPAID Bookings</h6>
                        <h2 class="text-right text-white"><i class="fas fa-rupee-sign float-left"></i><span>
                            <?=$unpaid_booking_count?>
                        </span></h2>                        
                    </div>
                </div>
            </a>
        </div>
    </div> -->
</div>
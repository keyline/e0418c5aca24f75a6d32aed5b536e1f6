<title><?php echo $title; ?></title>
				
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="" />
<meta name="keywords" content="">
<meta name="author" content="Codedthemes" />
				<!-- Favicon icon -->
<link rel="icon" href="<?php echo base_url(); ?>/uploads/<?php echo $site_setting->site_favicon; ?>" type="image/x-icon">

<!-- select2 css -->
<link rel="stylesheet" href="<?php echo base_url('material/'); ?>/assets/css/plugins/select2.min.css">

<link rel="stylesheet" href="<?php echo base_url('material/'); ?>/assets/css/plugins/bootstrap-tagsinput.css">
<link rel="stylesheet" href="<?php echo base_url('material/'); ?>/assets/css/plugins/bootstrap-tagsinput-typeahead.css">

<!-- vendor css -->
<link rel="stylesheet" href="<?php echo base_url('material/'); ?>/assets/css/style.css">
<!-- data tables css -->
<link rel="stylesheet" href="<?php echo base_url('material/'); ?>/assets/css/plugins/dataTables.bootstrap4.min.css">

<!-- ekko-lightbox css -->
<link rel="stylesheet" href="<?php echo base_url('material/'); ?>/assets/css/plugins/ekko-lightbox.css">
<link rel="stylesheet" href="<?php echo base_url('material/'); ?>/assets/css/plugins/lightbox.min.css">
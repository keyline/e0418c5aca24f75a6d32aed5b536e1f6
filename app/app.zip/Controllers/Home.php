<?php

namespace App\Controllers;

class Home extends BaseController
{
	public function index()
	{
		echo "Website is under construction. Please stay tuned..";die;
		// return view('welcome_message');
	}
}
